package com.everis.entidadesmongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntidadesMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
