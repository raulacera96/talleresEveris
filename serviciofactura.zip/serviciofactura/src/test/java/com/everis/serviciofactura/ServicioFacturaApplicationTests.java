package com.everis.serviciofactura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioFacturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
