package com.everis.serviciofactura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioFacturaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioFacturaApplication.class, args);
	}

}
