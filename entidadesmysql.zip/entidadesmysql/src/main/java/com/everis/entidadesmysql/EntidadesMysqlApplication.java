package com.everis.entidadesmysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntidadesMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntidadesMysqlApplication.class, args);
	}

}
