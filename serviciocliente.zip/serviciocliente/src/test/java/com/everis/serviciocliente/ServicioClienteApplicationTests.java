package com.everis.serviciocliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
