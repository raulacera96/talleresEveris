package com.everis.entidadestienda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntidadesTiendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
