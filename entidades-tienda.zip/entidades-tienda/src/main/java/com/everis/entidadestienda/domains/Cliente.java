package com.everis.entidadestienda.domains;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name="clientes")
public class Cliente {
    @Id
    private int id;

    @Column(name = "first_name")
    private String first_name;

    @Column(name = "last_name")
    private String last_name;

    @Column(name = "estado_cliente")
    private String estado_cliente;

    @OneToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL, mappedBy = "cliente_id")
    @JsonIgnore
    private Set<Direccion> direcciones;

    @OneToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL, mappedBy = "cliente_id")
    @JsonIgnore
    private Set<Visita> visitas;
}
