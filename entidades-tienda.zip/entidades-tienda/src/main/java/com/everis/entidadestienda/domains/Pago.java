package com.everis.entidadestienda.domains;

public class Pago {
}
