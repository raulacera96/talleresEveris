package com.everis.entidadestienda.domains;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import java.util.Date;

@Entity
@Table(name="direcciones")
public class Direccion {
    @Id
    private int id;

    @Column(name = "linea_dir")
    private String linea_dir;

    @Column(name = "provincia")
    private String provincia;

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;
}
