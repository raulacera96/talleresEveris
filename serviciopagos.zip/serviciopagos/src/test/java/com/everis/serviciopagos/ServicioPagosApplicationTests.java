package com.everis.serviciopagos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioPagosApplicationTests {

	@Test
	void contextLoads() {
	}

}
