package org.springframework.samples.petclinic;


import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.samples.petclinic.owner.Owner;




public class JDBCApplication {

	public static void main(String[] args) {
		System.out.println("-------- Test de conexión con MySQL ------------");

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("No encuentro el driver en el Classpath");
			e.printStackTrace();
			return;
		}

		System.out.println("Driver instalado y funcionando");
		Connection connection = null;
		Statement statement = null;
		
		
		
		
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/petclinic?serverTimezone=UTC&useSSL=false","root", "1234");
			if (connection != null)
				System.out.println("Conexión establecida");
			
		
			statement = connection.createStatement();
			
			//1.- Obtener todas las mascotas
			/*String sql1 = "SELECT * from owners";
			
			ResultSet rs = statement.executeQuery(sql1);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String first_name = rs.getString("first_name");
				String last_name = rs.getString("last_name");
				
				System.out.printf("Id: %d Nombre: %s \n", id, first_name, last_name);
			}	*/
			
			//2.- Ponernos como propietarios de una mascota
			/*String sql2 = "UPDATE pets set owner_id='00' where name='Sly";
			
			ResultSet rs = statement.executeQuery(sql2);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				int id_owner = rs.getInt("id_owner");
				
				System.out.printf("Id: %d Nombre: %s Propietario: %d \n", id, name, id_owner);
			}	*/
			//3.- modificar nuestra ciudad -> Sevilla
			
			//4.- Variable tipo string para buscar todos los dueños que coincidan en nombre y apellidos
			
			//RETO
			Owner o = new Owner();
			o.setId(98);
			o.setFirstName("Raúl");
			o.setLastName("Acera Sánchez");
			o.setAddress("Paseo Carmelitas, 11");
			o.setCity("Salamanca");
			o.setTelephone("123456789");
			
			String sql = "INSERT INTO owners (id, first_name, last_name, address, city, telephone) VALUES ('"+o.getId()+"','"+o.getFirstName()+"','"+o.getLastName()+"','"+o.getAddress()+"','"+o.getCity()+"','"+o.getTelephone()+"')";
			
			//int update = statement.executeUpdate(sql);
			
			String sqlOwners = "SELECT * from owners";
			
			ResultSet rs = statement.executeQuery(sqlOwners);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String first_name = rs.getString("first_name");
				String last_name = rs.getString("last_name");
				
				System.out.printf("Id: %d Nombre: %s \n", id, first_name, last_name);
			}
			
			String sqlDel = "DELETE from owners where id=99";
			ResultSet rsDel = statement.executeQuery(sqlDel);
			
			rs.close();
			rsDel.close();
			
			} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;
		} finally {
			try {
				if(statement != null)
					connection.close();
			} catch (SQLException se) {
		    	  
		    }
		    try {
		        if(connection != null)
		            connection.close();
		    } catch (SQLException se) {
		         	se.printStackTrace();
		    }
		}
		
		
		
		
		
		
	}

}
